import * as React from "react";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import AppBar from "@mui/material/AppBar";
import CssBaseline from "@mui/material/CssBaseline";
import Toolbar from "@mui/material/Toolbar";
import { images } from "../../utils/constants/images";
import { useTheme } from "@mui/material";
import SidebarItem from "../../components/Sidebar/SidebarItem";
import Wholesalers from "../Wholesalers/Wholesalers"

const drawerWidth = 240;

export default function Sidebar() {
  const theme = useTheme();
  return (
    <Box sx={{ display: "flex" }}>
      <CssBaseline />
      <AppBar
        elevation={0}
        position="fixed"
        sx={{
          zIndex: (theme) => theme.zIndex.drawer + 1,
          background: theme.palette.navbar,
        }}
      >
        <Toolbar sx={{ marginLeft: "36px" }}>
          <img src={images.logo} alt="logo" width="149px" height="42px" />
        </Toolbar>
      </AppBar>
      <Drawer
        variant="permanent"
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          [`& .MuiDrawer-paper`]: {
            width: drawerWidth,
            boxSizing: "border-box",
          },
        }}
      >
        <Toolbar />
        <Box sx={{ overflow: "auto", fontWeight: 500 }}>
          <SidebarItem text="Users" />
          <SidebarItem text="Roles" />
          <SidebarItem text="Companies" />
          <SidebarItem text="Wholesalers" active={true}/>
        </Box>  
      </Drawer>
      <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
        <Toolbar />
        <Wholesalers />
      </Box>
    </Box>
  );
}
