import { height } from '@mui/system';
import {Validators} from '../../../utils/validators'

export const FilterFormProps = () => {
    return [
        {
            label: 'First Name *',
            value: '',
            size: 'small',
            autoFocus: true,
            type: 'text',
            typeValue: 'text',
            variant: 'outlined',
            placeholder: '',
            field: 'firstName',
            validators: [
                { check: Validators.Name, message: 'Invalid Input' },
                { check: Validators.maxCharLimit, num : 35, message: 'Enter valid name' },
            ],
            required: true,
            responsive: { xs: 12, sm : 6 },     
            // sx :{width : '300px'},  
            sx: { 'mt': 2, mb: 1 },
            style : { backgroundColor: '#F0EFFF', width : "350px" }
        },
        {
            label: 'Last Name *',
            value: '',
            size: 'medium',
            type: 'text',
            typeValue: 'text',
            variant: 'outlined',
            placeholder: '',
            field: 'lastName',
            validators: [
                { check: Validators.Name, message: 'Invalid Input' },
                { check: Validators.maxCharLimit, num : 35,message: 'Enter valid name' },
            ],
            required: true,
            responsive: { xs: 12, sm : 6 }, 
            sx :{width : '300px'},  
            sx: { 'mt': 2, mb: 1 },
            style : { backgroundColor: '#F0EFFF', width : "350px" }
        },
        {
            label: 'Email ID *',
            value: '',
            size: 'medium',
            type: 'text',
            typeValue: 'text',
            variant: 'outlined',
            placeholder: '',
            field: 'email',
            validators: [
                { check: Validators.email, message: 'Enter valid email' },
            ],
            required: true,
            responsive: { xs: 12, sm : 6 }, 
            sx :{width : '300px'},  
            sx: { 'mt': 2, mb: 1 },
            style : { backgroundColor: '#F0EFFF',width : "350px" }
        },
        {
            label: 'Phone Number *',
            value: '',
            size: 'medium',
            type: 'text',
            typeValue: 'text',
            variant: 'outlined',
            placeholder: '',
            field: 'phone', 
            validators: [
                { check: Validators.mobile, message: 'Enter valid phone no.' },
            ],
            required: true,
            responsive: { xs: 12, sm : 6 }, 
            sx :{width : '300px'},  
            sx: { 'mt': 2, mb: 1 },
            style : { backgroundColor: '#F0EFFF', width : "350px" }
        },
        {
            label: 'Wholesaler ID *',
            value: '',
            size: 'medium',
            type: 'text',
            typeValue: 'text',
            variant: 'outlined',
            placeholder: '',
            field: 'locid',
            validators: [
                { check: Validators.localId, num : 6,message: 'ID should contain 6 characters' },
            ],
            required: true,
            responsive: { xs: 12, sm : 6 }, 
            sx :{width : '300px'},  
            sx: { 'mt': 2, mb: 1 },
            style : { backgroundColor: '#F0EFFF', width : "350px" }
        },

    ];
}
