import {useState} from 'react';
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import PrimaryButton from '../../../components/PrimaryButton';
import { FilterFormProps } from './FilterFormProps';
import { useRef } from 'react';
import Form from '../../../components/Form'
import axiosInstance from '../../../utils/axios';


const FilterForm = ({handleShow, getList,setShowMsg }) => {

    const [isLoading, setIsLoading] = useState(false);
    let FilterFormRef = useRef();
    const [hasError, setHasError] = useState(false);

    const handleAdd = async() => {
      const { getFormData } = FilterFormRef.current

      const { formData, isFormValid } = getFormData();
      
      const body = {email : formData.email, firstName : formData.firstName, lastName : formData.lastName , phoneNumber : 
        formData.phoneNumber, wholesalerId : formData.wholesalerId}
      
      try {
        setIsLoading(true)
        const response = await axiosInstance.post('/wholesaler/filter', body);
        getList();
        handleShow();
        setIsLoading(false)
        if(response.status === 200){
          setShowMsg(true)
        }
      } catch (error) { }
    }


  return (
    <form onSubmit={handleAdd}>

      
    <Box
      sx={{
        my: 2,
        mx: 8,
        display: "flex",
        flexDirection: "column",
        alignItems: "left",
      }}
    >


      <hr />

      <Grid container spacing = {1}>
      <Form
          hasError={hasError}
          ref={FilterFormRef}
          model={FilterFormProps()}
          values={{}}
      />
          </Grid>

        <Grid item xs={12} sm={12} mt={2}>
          <Stack spacing={2} direction="row">
            <PrimaryButton variant="contained" onClick={handleAdd}>Continue</PrimaryButton>
          </Stack>
        </Grid>
      
    </Box>
  </form>
  )
}

export default FilterForm