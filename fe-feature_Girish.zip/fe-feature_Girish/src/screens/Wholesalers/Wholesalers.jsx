import './Wholesalers.css'
import { useTheme, Grid, Stack, Divider, Typography, Box } from "@mui/material";
import FilterAltOutlinedIcon from "@mui/icons-material/FilterAltOutlined";
import { React, useState, useEffect, useCallback } from "react";
import { ModalView } from "../../components/ModalView/ModalView";
import axiosInstance from "../../utils/axios";
import UpdateForm from "./Update/UpdateForm";
import FilterForm from "./Filter/FilterForm";
import AddUser from "./Add/AddForm";
import PrimaryButton from "../../components/PrimaryButton";
import ListView from "../../components/ListView/ListView";
import Sorting from "../../components/Sorting/Sorting";
import PageLoader from "../../components/PageLoader";
import Notification from '../../components/Notification';


const Wholesalers = () => {

  const theme = useTheme();

  // for store the get data
  const [pageResponse, setPageResponse] = useState([]);

  // for pagination
  const [totalPage, setTotalPage] = useState(0);

  // for form popup
  const [showAdd, setShowAdd] = useState(false);
  const [showUpdate, setShowUpdate] = useState(false);
  const [showFilter, setShowFilter] = useState(false);
  
  // to track perticular user for update
  const [saler, setSalerData] = useState({});
  
  // to show on screen
  const [isLoading, setIsLoading] = useState(false);
  const [showMsg, setShowMsg] = useState(false);


  // Get list api calling
  const getList = useCallback(async () => {
    try {
      setIsLoading(true)
      const { data } = await axiosInstance.get("/wholesaler/get");
      setPageResponse(data);
      setTotalPage(Math.ceil(data.length / 5))
      setIsLoading(false)
    } catch (error) { }
  }, []);

  // get request call on first time page render
  useEffect(() => {
    (async () => {
      getList();
    })();
  }, [])


  // Delete api call
  const DeleteSaler = async (id) => {
    try {
      setIsLoading(true)
      const data = await axiosInstance.delete(`/wholesaler/delete/${id}`);
      getList();
      setIsLoading(false)
      setShowMsg(true)
    } catch (error) { }
  }

  // pop form toggle functions
  const handleShowAdd = () => {
    setShowAdd(!showAdd)
  }
  const handleShowUpdate = () => {
    setShowUpdate(!showUpdate)
  }
  const handleShowFilter = () => {
    setShowFilter(!showFilter)
  }

  return (
    <div>

      {isLoading && (
        <div className="overlay">
          <PageLoader />
        </div>

      )}

      <Stack direction="row" spacing={110}>
        <Typography
          sx={{ marginLeft: "10px" }}
          fontWeight={600}
          fontSize={18}
          color={theme.palette.primary.main}
        >
          Wholesalers
        </Typography>

        <div>
          <PrimaryButton size="small" sx={{ width: "70px" }} onClick={handleShowAdd}>
            ADD
          </PrimaryButton>

          <PrimaryButton
            size="small"
            startIcon={<FilterAltOutlinedIcon />}
            sx={{ width: "110px", marginLeft: "20px" }}
            onClick={handleShowFilter}
          >
            Filter
          </PrimaryButton>
        </div>
      </Stack>

      <Divider sx={{ marginTop: "1rem", borderBottomWidth: 2 }} />
      
      <Box sx = {{width : '1180px', marginLeft : '12px', marginRight : '15px', marginTop : '10px'}}>
      {showMsg && (
        <Notification severity={"success"} isOpen={showMsg} closeNotification={setShowMsg} message="Request Successfull, Action Completed....!"></Notification>
      )}</Box>

      <Box sx={{ position: "relative", left: "23px", flexGrow: 1, marginTop: "1rem", marginBottom: "1rem" }} width="95%">
        <Grid container spacing={2}>
          <Grid item xs={1.6}>
            {/* Title of table with sorting */}
            <Typography sx={{ color: theme.palette.headerFont, fontSize: 14 }}>
              <Sorting
                pageResponse={pageResponse}
                setPageResponse={setPageResponse}
                title={"First Name"}
                value = {"firstName"}
              />
            </Typography>
          </Grid>
          <Grid item xs={1.6}>
            <Typography sx={{ color: theme.palette.headerFont, fontSize: 14 }}>
              <Sorting
                pageResponse={pageResponse}
                setPageResponse={setPageResponse}
                title={"Last Name"}
                value = {"lastName"}
              />
            </Typography>
          </Grid>
          <Grid item xs={2.8}>
            <Typography sx={{ color: theme.palette.headerFont, fontSize: 14 }}>
              <Sorting
                pageResponse={pageResponse}
                setPageResponse={setPageResponse}
                title={"Email"}
                value = {"email"}
              />
            </Typography>
          </Grid>
          <Grid item xs={2}>
            <Typography style={{ marginTop: "0.5rem" }} sx={{ color: theme.palette.headerFont, fontSize: 14 }}>
              <span>
                Phone Number
              </span>
            </Typography>
          </Grid>
          <Grid item xs={2}>
            <Typography sx={{ color: theme.palette.headerFont, fontSize: 14 }}>
              <Sorting
                pageResponse={pageResponse}
                setPageResponse={setPageResponse}
                title={"Wholesaler ID"}
                value = {"wholesalerId"}
              />
            </Typography>
          </Grid>
          <Grid item xs={2}>
            <Typography sx={{ color: theme.palette.headerFont, fontSize: 14, marginTop: "0.5rem" }}>
              <span >
                Actions
              </span>
            </Typography>
          </Grid>
        </Grid>
      </Box>

      <ListView
        pageResponse={pageResponse}
        handleShowUpdate={handleShowUpdate}
        setSalerData={setSalerData}
        DeleteSaler={DeleteSaler}
        totalPage={totalPage}
      >
      </ListView>

      {/* POP UP FORM COMPONENT */}
      <ModalView
        show={showAdd} Component={AddUser} handleShow={handleShowAdd}
        getList={getList} formName={"Add Wholesaler"}
        setShowMsg={setShowMsg}
      />
      <ModalView
        show={showUpdate} Component={UpdateForm} handleShow={handleShowUpdate}
        saler={saler} getList={getList} formName={"Edit Wholesaler"}
        setShowMsg={setShowMsg}
      />
      <ModalView
        show={showFilter} Component={FilterForm} handleShow={handleShowFilter}
        getList={getList} formName={"Filters"}
        setShowMsg={setShowMsg}
      />
    </div>
  );
};

export default Wholesalers;


