import { useState } from 'react';
import {Grid, Stack, Box} from "@mui/material";
import PrimaryButton from '../../../components/PrimaryButton';
import { AddFormProps } from './AddFormProps'
import { useRef } from 'react';
import Form from '../../../components/Form'
import axiosInstance from '../../../utils/axios';
import PageLoader from '../../../components/PageLoader';
import Notification from '../../../components/Notification';


const AddForm = ({ getList, handleShow, setShowMsg }) => {

  let addFormRef = useRef();
  const [hasError, setHasError] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const [showServerAlert, setShowServerAlert] = useState(false);
  const [ServerErrorMsg, setServerErrorMsg] = useState('Error Occured');
  const [isLoading, setIsLoading] = useState(false);

  const handleAdd = async () => {
    const { getFormData } = addFormRef.current  
    const { formData, isFormValid } = getFormData();
    setHasError(isFormValid);

    const body = {
        email: formData.email, firstName: formData.firstName, lastName: formData.lastName, 
        locId: formData.locid.toUpperCase(), phoneNumber: formData.phoneNumber, role: formData.role, 
        wholesalerId: formData.wholesalerId.toUpperCase()
    }

    let response;
    if (isFormValid != false) {
      try {
        setIsLoading(true);
        response = await axiosInstance.post('/wholesaler/create', body);
        getList();
        handleShow();
        setIsLoading(false);
        if (response.status === 200) {
          setShowMsg(true)
        }
      } catch (error) {
        setIsLoading(false);
        setServerErrorMsg(error.response.data)
        setShowServerAlert(true)
      }
    }
    else {
      setShowAlert(true);
    }
  }


  return (
    <form onSubmit={handleAdd}>
      {/* warning if fields are not correct */}
      <Box sx = {{width : '85%', marginLeft : '60px'}}>
      {showAlert && (
        <Notification severity={"warning"} isOpen={showAlert} closeNotification={setShowAlert} message="All correct fileds are required...!" autoHideDuration={5000}/>)
      }</Box>

      {/* warning if fields are not unique*/}
      <Box sx = {{width : '85%', marginLeft : '60px'}}>
      {showServerAlert && (
       <Notification severity={"warning"} isOpen={showServerAlert} closeNotification={setShowServerAlert} message={ServerErrorMsg}/>)
      }</Box>

      {isLoading && (
        <div className="overlay">
          <PageLoader />
        </div>
      )}

      <Box
        sx={{
          my: 2,
          mx: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "left",
        }}
      >
        <hr />

        <Grid container spacing={1}>
          <Form
            hasError={hasError}
            ref={addFormRef}
            model={AddFormProps()}
            values={{}}
          />
        </Grid>

        <Grid item xs={12} sm={12} mt={2}>
          <Stack spacing={2} direction="row">
            <PrimaryButton variant="contained" onClick={handleAdd}>Add User</PrimaryButton>
          </Stack>
        </Grid>

      </Box>
    </form>

  )
}

export default AddForm