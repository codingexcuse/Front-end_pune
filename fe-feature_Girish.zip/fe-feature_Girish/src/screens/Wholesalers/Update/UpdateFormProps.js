import { height } from '@mui/system';
import {Validators} from '../../../utils/validators'

export const UpdateFormProps = () => {
    return [
        {
            label: 'First Name *',
            value: '',
            size: 'small',
            autoFocus: true,
            type: 'text',
            typeValue: 'text',
            variant: 'outlined',
            placeholder: '',
            field: 'firstName',
            validators: [
                { check: Validators.required, message: 'This field is mandatory' },
                { check: Validators.Name, message: 'Invalid Input' },
                { check: Validators.maxCharLimit, num : 35, message: 'Enter valid name' },

            ],
            required: true, 
            responsive: { xs: 12, sm : 4 }, 
            sx: { 'mt': 2, mb: 1 },
            style : { width : "250px"}
        },
        {
            label: 'Last Name *',
            value: '',
            size: 'medium',
            type: 'text',
            typeValue: 'text',
            variant: 'outlined',
            placeholder: '',
            field: 'lastName',
            sx :{width : '300px'},
            sx: { 'mt': 2, mb: 1 }, 
            validators: [
                { check: Validators.required, message: 'This field is mandatory' },
                { check: Validators.Name, message: 'Invalid Input' },
                { check: Validators.maxCharLimit, num : 35,message: 'Enter valid name' },
            ],
            responsive: { xs: 12, sm : 4 },
            required: true,
            style : { backgroundColor: '#F0EFFF',  width : "250px" } 
        },
        {
            label: 'Email ID *',
            value: '',
            size: 'medium',
            type: 'text',
            typeValue: 'text',
            variant: 'outlined',
            placeholder: '',
            field: 'email',
            
            sx: { 'mt': 2, mb: 1 },
            validators: [   
                { check: Validators.email, message: 'Enter valid email' },
                { check: Validators.required, message: 'This field is mandatory' },
            ],
            responsive: { xs: 12, sm : 4 },
            required: true,
            style : { backgroundColor: '#F0EFFF' , width : "250px"}
        },
        {
            label: 'Phone Number *',
            value: '',
            size: 'medium',
            type: 'text',
            typeValue: 'text',
            variant: 'outlined',
            placeholder: '',
            field: 'phoneNumber',
            sx: { 'mt': 2, mb: 1 },
            validators: [
                { check: Validators.required, message: 'This field is mandatory' },
                { check: Validators.mobile, message: 'Enter valid phone no.' },
            ],
            responsive: { xs: 12, sm : 4 },
            required: true,
            style : { backgroundColor: '#F0EFFF', width : "250px" }
        },
        {
            label: 'Wholesaler ID *',
            value: '',
            size: 'medium',
            type: 'text',
            typeValue: 'text',
            variant: 'outlined',
            placeholder: '',
            field: 'wholesalerId',
            sx: { 'mt': 2, mb: 1 },
            validators: [
                { check: Validators.required, message: 'This field is mandatory' },
                { check: Validators.localId, message: 'Enter Valid ID. Eg: ABC123' },
            ],
            responsive: { xs: 12, sm : 4 },
            required: true,
            style : {width : "250px" }
        },

        {
            label: "Role *",
            value: "",
            size: "medium",
            type: "drop-down",
            placeholder: "",
            field: "role",
            validators: [
                { check: Validators.required, message: "This field is mandatory" },
            ],
            responsive: { xs: 12, sm : 4 },
            required: true,
            options: ["Admin", "Client"],
            style: { position:"relative", top:"1rem", width : "250px"},
        },

        {
            label: 'LOC id *',
            value: '',
            size: 'medium',
            type: 'text',
            typeValue: 'text',
            variant: 'outlined',
            placeholder: 'GRI',
            field: 'locId',
            sx: { 'mt': 2, mb: 1 },
            validators: [
                { check: Validators.localId, message: 'Enter Valid ID. Eg: ABC123' },
                { check: Validators.required, message: 'This field is mandatory' },
            ],
            responsive: { xs: 12, sm : 4 },
            required: true,
            style : { backgroundColor: '#F0EFFF' , width : "250px"},
            disabled    : true
        },

    ];
}
