import { useState, useRef } from 'react';
import { useTheme, Grid, Stack, TextField, Box } from "@mui/material";
import styledComponent from "styled-components";
import PrimaryButton from '../../../components/PrimaryButton';
import { UpdateFormProps } from './UpdateFormProps';
import Form from '../../../components/Form'
import axiosInstance from '../../../utils/axios';
import PageLoader from '../../../components/PageLoader';
import Notification from '../../../components/Notification';


const UpdateForm = ({ saler, getList, handleShow, setShowMsg }) => {

  let updateFormRef = useRef();
  const [hasError, setHasError] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showAlert, setShowAlert] = useState(false);

  const [showServerAlert, setShowServerAlert] = useState(false);
  const [ServerErrorMsg, setServerErrorMsg] = useState('Error Occured');


  const handleAdd = async () => {
    const { getFormData } = updateFormRef.current
    const { formData, isFormValid } = getFormData();
    setHasError(isFormValid);

    const body = {
      email: formData.email, firstName: formData.firstName, lastName: formData.lastName, locId: formData.locId, phoneNumber:
        formData.phoneNumber, role: formData.role, wholesalerId: formData.wholesalerId
    }

    if (isFormValid != false) {
      try {
        setIsLoading(true);
        const response = await axiosInstance.put(`/wholesaler/update/${saler.id}`, body);
        getList();
        handleShow();
        setIsLoading(false);
        if (response.status === 200) {
          setShowMsg(true)
        }
      } catch (error) {
        // console.log(error)
        setIsLoading(false);
        setServerErrorMsg(error.response.data)
        setShowServerAlert(true)
      }
    }
    else {
      setShowAlert(true);
    }
  }

  return (
    <form onSubmit={handleAdd}>
      {isLoading && (
        <div className="overlay">
          <PageLoader />
        </div>)}


      {/* warning if fields are not correct */}
      <Box sx={{ width: '40px' }}>
        {showAlert && (
          <Notification severity={"warning"} isOpen={showAlert} closeNotification={showAlert} message="All correct fileds are required...!" />)
        }</Box>

      {/* warning if fields are not unique*/}
      <Box sx={{ width: '85%', marginLeft: '60px' }}>
        {showServerAlert && (
          <Notification severity={"warning"} isOpen={showServerAlert} closeNotification={setShowServerAlert} message={ServerErrorMsg} />)
        }</Box>

      <Box
        sx={{
          my: 2,
          mx: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "left",
        }}
      >

        <hr />

        <Grid container spacing={1}>
          <Form
            hasError={hasError}
            ref={updateFormRef}
            model={UpdateFormProps(saler)}
            values={saler}
          />
        </Grid>

        <Grid item xs={12} sm={12} mt={2}>
          <Stack spacing={2} direction="row">
            <PrimaryButton variant="contained" onClick={handleAdd}>Update</PrimaryButton>
          </Stack>
        </Grid>

      </Box>
    </form>
  )
}

export default UpdateForm;