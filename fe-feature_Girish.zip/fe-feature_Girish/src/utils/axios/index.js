import Axios from "axios";

const baseURL = "http://13.233.74.100:8088/";

const axiosInstance = Axios.create({
  baseURL: baseURL,
  headers: { "Content-Type": "application/json" },
});

axiosInstance.defaults.timeout = 300000;

export default axiosInstance;
