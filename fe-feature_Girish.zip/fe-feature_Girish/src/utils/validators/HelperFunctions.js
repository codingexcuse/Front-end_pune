

// Function
export function getFormFields(formData) {
  const fields = {};
  for (const key in formData) {
      if (!key.includes('Error')) {
          fields[key] = formData[key];
      }
  }
  return fields;
}

export const removeErrorFieldsFromValues = (formData) => {
    const fields = {};
    for (const key in formData) {
        if (!key.includes('Error')) {
            fields[key] = formData[key];
        }
    }
    return fields;
};

export const createDropdownData = (data = [], keys = []) => {
    const createdArray = [];
    if (data && data?.length) {
      data?.forEach((item) => {
        createdArray?.push({
          value: item[keys[0]],
          label: item[keys[1]],
        });
      });
    }
    return createdArray;
  };
  
  /**
   * This function will extract `value` from selected multiple dropdown. This will only used when Dropdown component has isMulti: true
   * @param values - selected values from dropdown
   * @returns {[]}
   */
  export const fetchIdsFromSelectedDropdownValues = (values = []) => {
    const extractedValue = [];
    if (values && values.length) {
      values.forEach((item) => {
        extractedValue.push(item.value);
      });
    }
    return extractedValue;
  };
  export const fetchLabelsFromSelectedDropdownValues = (values = []) => {
    const extractedValue = [];
    if (values && values.length) {
      values.forEach((item) => {
        extractedValue.push(item.label);
      });
    }
    return extractedValue.join(',');
  };
