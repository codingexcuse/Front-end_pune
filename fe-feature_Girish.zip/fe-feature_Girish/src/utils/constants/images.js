import logo from "../../assets/images/logo.svg";

export const images = {
  logo,
};
