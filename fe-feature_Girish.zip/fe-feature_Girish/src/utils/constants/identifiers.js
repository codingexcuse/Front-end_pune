export const identifiers = {
    date_format: "DD/MM/YYYY",
    date_input: "YYYY-MM-DD",
    field_error: "This Field is Required",
  };
  