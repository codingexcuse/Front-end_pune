import Sidebar from "./screens/Sidebar/Sidebar";


function App() {
  return (
    <div>
      <Sidebar/>
    </div>
  );
}

export default App;
