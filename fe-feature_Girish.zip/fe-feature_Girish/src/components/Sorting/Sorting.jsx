import React from 'react'
import { useState } from 'react';
import ArrowUpwardOutlinedIcon from "@mui/icons-material/ArrowUpwardOutlined";
import ArrowDownwardOutlinedIcon from "@mui/icons-material/ArrowDownwardOutlined";

const Sorting = ({ pageResponse, setPageResponse, title, value }) => {

  // for sorting
  const [order, setOrder] = useState(true);
  // "acs" === true, "dec" === false

  const handleOrder = () => {
    setOrder(!order)
  }

  const handleSorting = () => {

    setPageResponse(prevData => {
      const sortedData = [...prevData].sort((a, b) => {
        if (order) {
          return a[value].localeCompare(b[value]);
        } else {
          return b[value].localeCompare(a[value]);
        }
      });
      return sortedData;
    });

    handleOrder();
  };

  return (
    <span
      className="headerTitle"
      onClick={() => {
        handleSorting()
      }
      }>

      <span className="toggleArrow">
        {title}
      </span>

      {order === true && (
        <ArrowUpwardOutlinedIcon
          className="sortArrow"
          sx={{ position: "relative", top: "0.3rem" }}
        />
      )}
      {order === false && (
        <ArrowDownwardOutlinedIcon
          className="sortArrow"
          sx={{ position: "relative", top: "0.3rem" }}
        />
      )}
    </span>
  )
}

export default Sorting



