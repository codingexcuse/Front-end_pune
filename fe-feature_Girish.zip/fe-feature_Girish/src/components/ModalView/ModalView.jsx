import React from 'react'
import CloseSharpIcon from '@mui/icons-material/CloseSharp';
import { Backdrop, Modal, Fade, IconButton, useTheme } from "@mui/material";
import Divider from "@mui/material/Divider";
import Typography from '@mui/material/Typography';
import { Grid } from '@mui/material';


import "./styles.css"

export const ModalView = ({ Component, show, handleShow, saler, getList, formName, setShowMsg}) => {

  const theme = useTheme()
  return (
    <div>
      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        // className={classes.modal}
        open={show}
        onClose={handleShow}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={show}>
          {/* <Container  sx = {{maxWidth : {xs : 'xs', sm : 'sm', md : 'md', lg : 'lg', xl : 'xl'}}}> */}
          <div className="popform">

            <Grid container justifyContent="space-between" alignItems="center" style={{ marginTop: 20 }} >
              <Grid item>
                <Typography sx={{
                  fontStyle: "normal",
                  fontWeight: "600",
                  fontSize: "20px",
                  color: "#4D47C3",
                  lineHeight: "24px",

                }}
                  style={{ marginLeft: 65 }}>

                  {formName}
                </Typography>
              </Grid>
              <Grid item>
                <IconButton onClick={handleShow}
                  sx={{

                    backgroundColor: theme.palette.secondary.main,
                    color: theme.palette.primary.main,
                    borderRadius: "0.5rem",
                  }}
                  style={{ marginRight: 40 }}
                >
                  <CloseSharpIcon /></IconButton>
              </Grid>

            </Grid>

            <Divider sx={{ marginLeft: "25px", marginTop: "20px", borderBottomWidth: 2, width: 900 }} />
            <Component saler={saler} getList={getList} handleShow={handleShow} setShowMsg = {setShowMsg}/>
          </div>
          {/* </Container> */}
        </Fade>
      </Modal>
    </div>
  )
}
