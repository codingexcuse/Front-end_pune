import React from 'react';
import Alert from '@mui/material/Alert';
import Box from '@mui/material/Box';
import LinearProgress from '@mui/material/LinearProgress';
import { useEffect, useState } from 'react';

const Notification = ({ isOpen, closeNotification, severity, message}) => {

  // Hide success message after 3 seconds
  const hideMessage = () => { 
    setTimeout(handleClose, 3000);
  };
  
  const handleClose = () => {
    closeNotification(false)
  }

  const renderFields = () => {
    if (isOpen) {
      hideMessage();
      return (
        <Box sx={{ width: '100%' }}>
          <Alert onClose={handleClose} severity={severity} sx={{ width: "100%" }}>
            {message}
          </Alert>
          {/* <LinearProgress variant="determinate" /> */}
        </Box>
      );
    }
  };

  return <div>
    {renderFields()}
  </div>;
};

export default Notification;