import Box from "@mui/material/Box";
import React from "react";
import Typography from "@mui/material/Typography";
import { useTheme } from "@mui/material";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import { Grid } from "@mui/material";
import { useState } from "react";
import PaginationComponent from "../Pagination/Pagination";
import DeleteAlert from "../DleteAlert";


const ListView = ({ pageResponse, handleShowUpdate, setSalerData, DeleteSaler, totalPage }) => {

    const theme = useTheme();

    // for pagination
    const [prevPage, setPrevPage] = useState(5);
    const [showPage, setShowPage] = useState(1);

    // for delete
    const [DeleteAlertOpen, setOpen] = useState(false);
    const [user, setUser] = useState({})

    // to set pagination
    const handlePagination = (page) => {
        setPrevPage(page * 5);
    };


    const handleClickOpen = () => {
        setOpen(true);
    };


    return (
        <div>
            <DeleteAlert open={DeleteAlertOpen} setOpen={setOpen} DeleteSaler={DeleteSaler} id={user.id}></DeleteAlert>

            <Box sx={{ flexGrow: 1, position: "relative", left: "23px" }} width="95%" >
                {pageResponse.slice(prevPage - 5, prevPage).map((user) => {
                    return (
                        <Grid key={user.id} container spacing={2} sx={{ borderRadius: "8px", backgroundColor: theme.palette.secondary.main, marginTop: "1rem" }}>
                            <Grid item xs={1.6}>
                                <Typography
                                    sx={{ fontSize: 14, marginBottom: "1rem" }}
                                >
                                    {user.firstName}
                                </Typography>
                            </Grid>
                            <Grid item xs={1.6}>
                                <Typography
                                    sx={{ fontSize: 14 }}
                                >
                                    {user.lastName}
                                </Typography>
                            </Grid>
                            <Grid item xs={2.8}>
                                <Typography
                                    sx={{ fontSize: 14 }}
                                >
                                    {user.email}
                                </Typography>
                            </Grid>
                            <Grid item xs={2}>
                                <Typography
                                    sx={{ fontSize: 14 }}
                                >
                                    {user.phoneNumber}
                                </Typography>
                            </Grid>
                            <Grid item xs={2}>
                                <Typography
                                    sx={{ fontSize: 14 }}
                                >
                                    {user.wholesalerId}
                                </Typography>
                            </Grid>
                            <Grid item xs={2}>
                                <Typography
                                    sx={{ fontSize: 14 }}
                                >
                                    <EditOutlinedIcon
                                        fontSize="small"
                                        sx={{
                                            cursor: "pointer",
                                            color: theme.palette.primary.main,
                                        }}

                                        // ON UPDATE FORM POPUP
                                        onClick={() => {
                                            setSalerData(user)
                                            handleShowUpdate();
                                        }}

                                    />
                                    <DeleteOutlineOutlinedIcon
                                        onClick={() => {
                                            handleClickOpen(user.id);
                                            setUser(user)
                                        }
                                        }
                                        fontSize="small"
                                        sx={{
                                            marginLeft: "2rem",
                                            cursor: "pointer",
                                            color: theme.palette.primary.main,
                                        }}

                                    />
                                </Typography>
                            </Grid>
                        </Grid>

                    );
                })}
            </Box>

            <Box sx={{ flexGrow: 1, position: "relative", left: "23px" }} width="95%">
                <Grid container spacing={2} sx={{ marginTop: "1rem" }}>
                    <Grid item xs={4}>
                        <Typography
                            sx={{
                                fontSize: 14,
                                marginBottom: "1rem",
                                color: theme.palette.headerFont,
                            }}
                        >
                            Page: {showPage}
                        </Typography>
                    </Grid>
                    <Grid item xs={8}>
                        <PaginationComponent
                            totalPage={totalPage}
                            handlePagination={handlePagination}
                            setShowPage={setShowPage}
                        />
                    </Grid>
                </Grid>
            </Box>
        </div>
    )
}

export default ListView