import logo from "../../assets/images/logo.svg";
import crossIcon from "../../assets/images/cross-icon.svg";

export const images = {
  logo,
  crossIcon,
};
