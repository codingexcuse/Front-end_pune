import * as React from 'react';
import axios from 'axios';
import { useState, useEffect } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import AddUser from '../AddUser/AddUser';
import { Backdrop, Modal, Fade } from '@mui/material';

// const [roleName, setRoleName] = useState("");
//   const [organizationName, setOrganizationName] = useState("");
//   const [date, setDate] = useState("");
//   const [roleState, setRoleState] = useState("");
//   const [roleId, setRoleId] = useState("");
//   const [userState, setuserState] = useState('');

const columns = [

    {
        field: 'roleName',
        headerName: 'role Name',
        type: 'string',
        description: 'This column has a value getter and is not sortable.',
        sortable: false,
        width: 160,
        valueGetter: (params) =>
            `${params.row.roleName}`,
    },
    { 
        field: 'organizationName', 
        headerName: 'organizationName', 
        type:'string',
        width: 200 },

    {
        field: 'date',
        headerName: 'date',
        type: 'date',
        width: 200,
    },

    {
        field: 'roleState',
        headerName: 'role State',
        type: 'boolean',
        width: 200,
    },

    {
        field: 'roleId',
        headerName: 'role Id',
        type: 'number',
        width: 200,
    },
    {
        field: 'actions',
        headerName: 'Actions',
        width: 200,
    },


];


export default function DataTable() {

    const [data, setData] = useState([]);
    const [open, setOpen] = useState(false);

    const fetchData = async () => {
        const response = await axios.get('http://3.110.25.149:8098/users/get');
        setData(response.data);
    }

    useEffect(() => {
        fetchData();
    }, []);

    const handleOpen = () => {
        setOpen(true);
    }

    const handleClose = () => {
        setOpen(false);
    }


    return (
        <div style={{ height: 400, width: '100%' }}>

        <button onClick={handleOpen}>Add</button>
            <Modal
                aria-labelledby="transition-modal-title"
                aria-describedby="transition-modal-description"
                // className={classes.modal}
                open={open}
                onClose={handleClose}
                closeAfterTransition
                BackdropComponent={Backdrop}
                BackdropProps={{
                    timeout: 500,
                }}
            >
                <Fade in={open}>
                    
                    <div className = "popform">
                        <button onClick={handleClose}>CLOSE</button>
                        <AddUser/>
                    </div>
                </Fade>
            </Modal>     


            <DataGrid
                rows={data}
                columns={columns}
                // pageSize={5}
                // rowsPerPageOptions={[5]}
            />
        </div>
    );
}
