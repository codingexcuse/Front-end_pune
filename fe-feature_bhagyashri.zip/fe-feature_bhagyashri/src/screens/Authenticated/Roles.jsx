import Box from "@mui/material/Box";
import React, { useCallback, useEffect, useState } from "react";
import Typography from "@mui/material/Typography";
import { useTheme } from "@mui/material";
import PrimaryButton from "../../components/PrimaryButton/PrimaryButton";
import FilterAltOutlinedIcon from "@mui/icons-material/FilterAltOutlined";
import Divider from "@mui/material/Divider";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import { Grid } from "@mui/material";
import axios from "axios";
import "./Roles.css";
import ArrowUpwardOutlinedIcon from "@mui/icons-material/ArrowUpwardOutlined";
import ArrowDownwardOutlinedIcon from "@mui/icons-material/ArrowDownwardOutlined";
import PaginationComponent from "../../components/Pagination/Pagination";

import { Backdrop, Modal, Fade, IconButton } from "@mui/material";
import CloseSharpIcon from "@mui/icons-material/CloseSharp";
import AddUser from "../AddUser/AddUser";
import EditUser from "../EditUser/EditUser";
import Filters from "../Filter/Filters";
import { Button } from "@material-ui/core";
import ClearButton from "../../components/ClearButton/ClearButton";
import ModalComponent from "../../components/Modal/ModalComponent";
import PopUp from "../../components/PopUp/PopUp";
import AlertMessage from "../../components/Alert/Alert";
import LoadingBar from "react-top-loading-bar";
import Tooltip from "@material-ui/core/Tooltip";

const Roles = ({createdDate}) => {
  const theme = useTheme();
  const [data, setData] = useState([]);
  const [prevPage, setPrevPage] = useState(5);
  const [order, setOrder] = useState("ASC");
  const [totalPage, setTotalPage] = useState(0);
  const [open, setOpen] = useState(false);
  const [upcreateddateOpen, setUpcreateddateOpen] = useState(false);
  const [filterOpen, setFilterOpen] = useState(false);
  const [showPage, setShowPage] = useState(1);
  const [getId, setGetId] = useState('');

  const [userData, setUserData] = useState();
  const [myuser, setMyuser] = useState();
  const [showDeleteErrorMessage, setDeleteShowErrorMessage] = useState(false);
  const [showDeleteSuccessMessage, setDeleteSuccessMessage] = useState(false);
  const [showAddErrorMessage, setAddShowErrorMessage] = useState(false);
  const [showAddSuccessMessage, setShowAddSuccessMessage] = useState(false);
  const [responseErrorMessage, setResponseErrorMessage] = useState("");
  // const [responseSucsessMessage, setResponseSuccessMessage] = useState("");
  const [progress, setProgress] = useState(0);





  const fetchData = useCallback(async () => {
    setProgress(20)
    const response = await axios.get('http://192.168.1.15:8098/api/v1/role');
    console.log(data);
    setProgress(60)
    setData(response.data);
    console.log(response.data)
    // console.log("Formatdate", role.formatDate);
    setTotalPage(Math.ceil(response.data.length / 5));
    setProgress(100)
  }, []);

  useEffect(() => {
    fetchData();
  }, []);




  const deleteData = async (roleId) => {
    setProgress(20)
    try {
      const response = await axios.delete(`http://192.168.1.15:8098/api/v1/role/delrole/${roleId}`);
      fetchData();
      setDeleteSuccessMessage(true)
      setProgress(60)
    } catch (e) {
      console.log(e)
      setDeleteShowErrorMessage(true)
      setProgress(60)
    }


    setProgress(100)

  };


  const handleSorting = (value) => {
    console.log(value)
    if (order === "ASC") {
      const sorted = [...data].sort((a, b) =>
        a[value].toLowerCase() > b[value].toLowerCase() ? 1 : -1
      );
      setData(sorted);
      setOrder("DSC");
    }
    if (order === "DSC") {
      const sorted = [...data].sort((a, b) =>
        a[value].toLowerCase() < b[value].toLowerCase() ? 1 : -1
      );
      setData(sorted);
      setOrder("ASC");
    }
  };

  const ClearFilter = () => {
    setData(data);
    console.log("cleared data",data);
  }

  //   const handleSorting = async (value) => {
  //     console.log('Helo');
  //     try {
  //       const response = await axios.get('http://3.110.25.149/api/v1/role/sort');
  //       console.log("Sorting Done");
  //       fetchData();
  //      } catch (e) { 
  //       console.log(e);
  //       setAddShowErrorMessage(true)
  //       setResponseErrorMessage(e.response.data.message);
  //     }
  //  };


  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(!open);
  };

  const handleUpcreateddateOpen = (id) => {
    setGetId(id)
    setUpcreateddateOpen(true);
  };

  const handleUpcreateddateClose = () => {
    setUpcreateddateOpen(!upcreateddateOpen);
  };

  const handleFilterOpen = () => {
    setFilterOpen(true);
  };

  const handleFilterClose = () => {
    setFilterOpen(!filterOpen);
  };

  const handlePagination = (page) => {
    setPrevPage(page * 5);
  };

  const handleDeleteMessage = () => {
    setTimeout(() => {
      setDeleteShowErrorMessage(false);
      setDeleteSuccessMessage(false);
      setAddShowErrorMessage(false);
      setShowAddSuccessMessage(false);
    }, 4000);
  };


  const handleUpcreateddateUser = (myuser) => {
    setUpcreateddateOpen(true);
    setMyuser(myuser);
  }


  return (
    <div>
      <LoadingBar
        height={3}
        color="#4D47C3"
        progress={progress}
        shadow={true}
      />

      <Box
        sx={{
          position: "relative",
          left: "23px",
          flexGrow: 1,
          marginTop: "1rem",
          marginBottom: "1rem",
        }}
        width="95%"
      >
        <Grid container spacing={2}>
          <Grid item xs={2.3}>
            <Typography
              sx={{ marginLeft: "20px", top: "200px", fontFamily: "Montserrat" }}
              fontWeight={600}
              fontSize={20}
              color={theme.palette.primary.main}
            >
              Roles
            </Typography>
          </Grid>
          <Grid item xs={6.7}>
            {handleDeleteMessage()}
            <AlertMessage
              isError={showDeleteErrorMessage}
              isSuccess={showDeleteSuccessMessage}
              errorMessage={`Error! Please Try Again`}
              successMessage="Successfully Deleted!"
            />
            <AlertMessage
              isError={showAddErrorMessage}
              isSuccess={showAddSuccessMessage}
              errorMessage={responseErrorMessage}
              successMessage="Successfully Added!"
            />
          </Grid>


          <Grid item xs={3}>

            <PrimaryButton
              onClick={handleOpen}
              size="small"
              sx={{ width: "82px", height: '36px', marginLeft: '0px', radius: '6px', padding: '9px, 25px, 9px, 25px', fontFamily: "Montserrat" }}
            >
              {/* padding: '9px, 25px, 9px, 25px', */}
              {/* top: '129px', left:'1563px' */}
              ADD
            </PrimaryButton>

            <PrimaryButton
              onClick={handleFilterOpen}
              size="small"
              startIcon={<FilterAltOutlinedIcon />}
              sx={{ width: "110px", height: '36px', marginLeft: "20px", fontFamily: "Montserrat" }}
            >
              Filter
            </PrimaryButton>

            <PrimaryButton
              onClick={ClearFilter}
              size="small"
              startIcon={<FilterAltOutlinedIcon />}
              sx={{ width: "110px", height: '36px', marginLeft: "20px", fontFamily: "Montserrat" }}
            >
              Clear Filter
            </PrimaryButton>
          </Grid>
        </Grid>
      </Box>

      <Divider sx={{ marginTop: "2rem", borderBottomWidth: 2 }} />

      <Box
        sx={{
          position: "relative",
          left: "23px",
          flexGrow: 1,
          marginTop: "1rem",
          marginBottom: "1rem",
        }}
        width="95%"
        height="50px"
      >
        <Grid container spacing={2}>
          <Grid item xs={2}>
            <Typography sx={{ color: theme.palette.headerFont, fontSize: 14 }}>
              <span
                className="headerTitle"
                onClick={() => handleSorting("roleName")}
              >
                <span className="toggleArrow">Role Name</span>
                {order === "ASC" && (
                  <ArrowUpwardOutlinedIcon
                    className="sortArrow"
                    sx={{ position: "relative", top: "0.3rem" }}
                  />
                )}
                {order === "DSC" && (
                  <ArrowDownwardOutlinedIcon
                    className="sortArrow"
                    sx={{ position: "relative", top: "0.3rem" }}
                  />
                )}
              </span>
            </Typography>
          </Grid>
          <Grid item xs={2.8}>
            <Typography sx={{ color: theme.palette.headerFont, fontSize: 14 }}>
              <span
                className="headerTitle"
                onClick={() => handleSorting("orgName")}
              >
                <span className="toggleArrow">Organization Name</span>
                {order === "ASC" && (
                  <ArrowUpwardOutlinedIcon
                    className="sortArrow"
                    sx={{ position: "relative", top: "0.3rem" }}
                  />
                )}
                {order === "DSC" && (
                  <ArrowDownwardOutlinedIcon
                    className="sortArrow"
                    sx={{ position: "relative", top: "0.3rem" }}
                  />
                )}
              </span>
            </Typography>
          </Grid>
          <Grid item xs={1.9}>
            <Typography sx={{
              color: theme.palette.headerFont, fontSize: 14,
              marginTop: "0.5rem",
            }}>

              Created Date
            </Typography>
          </Grid>
          <Grid item xs={1.7}>
            <Typography sx={{ color: theme.palette.headerFont, fontSize: 14 }}>
              <span
                className="headerTitle"
                onClick={() => handleSorting("rolestate")}
              >
                <span className="toggleArrow">Role State</span>
                {order === "ASC" && (
                  <ArrowUpwardOutlinedIcon
                    className="sortArrow"
                    sx={{ position: "relative", top: "0.3rem" }}
                  />
                )}
                {order === "DSC" && (
                  <ArrowDownwardOutlinedIcon
                    className="sortArrow"
                    sx={{ position: "relative", top: "0.3rem" }}
                  />
                )}
              </span>
            </Typography>
          </Grid>
          <Grid item xs={1.5}>
            <Typography sx={{
              color: theme.palette.headerFont, fontSize: 14,
              marginTop: "0.5rem",
            }}>
              Role ID
            </Typography>
          </Grid>

          <Grid item xs={2}>
            <Typography
              sx={{
                color: theme.palette.headerFont,
                fontSize: 14,
                marginTop: "0.5rem",
                width: '51px', height: '21px'
              }}
            >
              Actions
            </Typography>
          </Grid>
        </Grid>
      </Box>

      <Box sx={{ flexGrow: 1, position: "relative", left: "23px" }} width="95%" height="400px">
        {data.slice(prevPage - 5, prevPage).map((role, index) => {
          return (
            <Grid
              key={index}
              container spacing={2}
              sx={{
                borderRadius: "8px",
                backgroundColor: theme.palette.secondary.main,
                marginTop: "1rem",
              }}
            >
              <Grid item xs={2}>
                <Typography sx={{ fontSize: 14, marginBottom: "1rem", width: '76px', height: '21px' }}>
                  {role.roleName}
                </Typography>
              </Grid>
              <Grid item xs={2.8}  >
                <Typography sx={{ fontSize: 14, width: '135px', height: '21px' }}>{role.orgName}</Typography>
              </Grid>
              <Grid item xs={1.9}>
                <Typography sx={{ fontSize: 14, width: '95px', height: '21px' }}>
                  
                  {role.createdDate}
                </Typography>
              </Grid>
              <Grid item xs={1.7}>
                <Typography sx={{ fontSize: 14, width: '70px', height: '21px' }}>
                  {role.rolestate ? "ACTIVE" : "INACTIVE"}
                </Typography>
              </Grid>
              <Grid item xs={1.5}>
                <Typography sx={{ fontSize: 14, width: '47px', height: '21px' }}>
                  {role.roleId}
                </Typography>
              </Grid>


              <Grid item xs={2}>
                <Typography sx={{ fontSize: 14 }}>
                  <Tooltip title="Edit">
                    <EditOutlinedIcon
                      onClick={() => handleUpcreateddateUser(role)}
                      fontSize="small"
                      sx={{
                        cursor: "pointer",
                        color: theme.palette.primary.main,
                      }}
                    />
                  </Tooltip>


                  {/* <PopUp id={role.id} deleteById={deleteData} />  */}


                  <PopUp id={role.roleId} deleteById={deleteData} />
                  {/* <Tooltip title="Delete">
                  <DeleteOutlineOutlinedIcon
                    fontSize="small"
                    sx={{
                      marginLeft: "2rem",
                      cursor: "pointer",
                      color: theme.palette.primary.main,
                    }}
                    
                    onClick = {() =>deleteData(role.id)}
                  />
                  </Tooltip> */}

                </Typography>
              </Grid>
            </Grid>
          );
        })}
      </Box>
      <Box sx={{ flexGrow: 1, position: "relative", left: "23px" }} width="95%">
        <Grid container spacing={2} sx={{ marginTop: "1rem" }}>
          <Grid item xs={4}>
            <Typography
              sx={{
                fontSize: 14,
                marginBottom: "1rem",
                color: theme.palette.headerFont,
              }}
            >
              Page: {showPage}
            </Typography>
          </Grid>
          <Grid item xs={8}>
            <PaginationComponent
              totalPage={totalPage}
              handlePagination={handlePagination}
              setShowPage={setShowPage} 
            />
          </Grid>
        </Grid>
      </Box>

      <ModalComponent
        setProgress={setProgress}
        setIsError={setAddShowErrorMessage}
        setIsSuccess={setShowAddSuccessMessage}
        setResponseErrorMessage={setResponseErrorMessage}
        showClear={false}
        open={open}
        handleClose={handleClose}
        fetchData={fetchData}
        Component={AddUser}
        errorMessage={responseErrorMessage}

      />
      <ModalComponent
        setProgress={setProgress}
        setIsError={setAddShowErrorMessage}
        setIsSuccess={setShowAddSuccessMessage}
        setResponseErrorMessage={setResponseErrorMessage}
        showClear={false}
        open={upcreateddateOpen}
        handleClose={handleUpcreateddateClose}
        fetchData={fetchData}
        Component={EditUser}
        data={myuser} />
      <ModalComponent
        showClear={true}
        open={filterOpen}
        handleClose={handleFilterClose}
        fetchData={fetchData}
        Component={Filters}
        setData={setData}
      />
    </div>
  );
};

export default Roles;
