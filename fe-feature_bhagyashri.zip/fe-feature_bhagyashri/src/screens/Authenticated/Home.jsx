import * as React from "react";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import AppBar from "@mui/material/AppBar";
import CssBaseline from "@mui/material/CssBaseline";
import Toolbar from "@mui/material/Toolbar";
import { images } from "../../utils/constants/images";
import { useTheme } from "@mui/material";
import Roles from '../Authenticated/Roles'
import SidebarItem from "../../components/SidebarItem/SidebarItem";
import { useState } from "react";
const drawerWidth = 250;





export default function Home() {
  const theme = useTheme();
  const [userActive, setUserActive] = useState(false)
const [roleActive, setRoleActive] = useState(true)
const [companiesActive, setCompaniesActive] = useState(false)
const [wholesalerActive, setWholesalerActive] = useState(false)

const handleClick=(value)=>{
  switch(value) {
    case 'Users':
      setUserActive(true)
      setRoleActive(false)
      setCompaniesActive(false)
      setWholesalerActive(false)
      break;
    case 'Roles':
      setUserActive(false)
      setRoleActive(true)
      setCompaniesActive(false)
      setWholesalerActive(false)
      break;
      case 'Companies':
      setUserActive(false)
      setRoleActive(false)
      setCompaniesActive(true)
      setWholesalerActive(false)
      break;
      case 'Wholesalers':
        setUserActive(false)
        setRoleActive(false)
        setCompaniesActive(false)
        setWholesalerActive(true)
        break;
      default:
        setRoleActive(true)
        break;

  }
}
  return (
    <Box sx={{ display: "flex" }}>
      <CssBaseline />
      <AppBar
        elevation={0}
        position="fixed"
        sx={{
          zIndex: (theme) => theme.zIndex.drawer + 1,
          background: theme.palette.navbar,
        }}
      >
        <Toolbar sx={{ marginLeft: "36px" }}>
          <img src={images.logo} alt="logo" width="149px" height="42px" />
        </Toolbar>
        
      </AppBar>
      <Drawer
        variant="permanent"
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          [`& .MuiDrawer-paper`]: {
            width: drawerWidth,
            boxSizing: "border-box",
          },
        }}
      >
        <Toolbar />
        <Box sx={{ overflow: "auto", fontWeight: 500 }}>
        
          <span onClick={()=> {handleClick('Users')}}>
          <SidebarItem text="Users" active={userActive}/>
          </span>
          <span onClick={()=> {handleClick('Roles')}}>
          <SidebarItem text="Roles" active={roleActive}/>
          </span>
          <span onClick={()=> {handleClick('Companies')}}>
          <SidebarItem text="Companies" active={companiesActive}/>
          </span>
          <span onClick={()=> {handleClick('Wholesalers')}}>
          <SidebarItem text="Wholesalers" active={wholesalerActive}/>
          </span>
        </Box>
      </Drawer>
      <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
        <Toolbar />
        <Roles/>
        
      </Box>
    </Box>
  );
}
