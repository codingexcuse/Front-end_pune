import { useState } from "react";
import TextField from "@mui/material/TextField";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import MenuItem from "@mui/material/MenuItem";
import Stack from "@mui/material/Stack";
import styledComponent from "styled-components";
// import "./styles.css";
// import './styles.css'
import { useTheme } from "@mui/material";
import axios from "axios";
import PrimaryButton from "../../components/PrimaryButton/PrimaryButton";
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import AlertDialog from "../../components/ConfirmationBox/ConfirmationBox";
import Divider from "@mui/material/Divider";
import moment from "react-moment";

const CustomTextField = styledComponent(TextField)`
  & label.Mui-focused {
    color: #4D47C3;
  }
  & .MuiOutlinedInput-root {
    &.Mui-focused fieldset {
     border-color: #4D47C3;
      
    }
  }
`;

const roledropdownValue = [
  {
    value: "SUPER_ADMIN",
    label: "SUPER_ADMIN",
  },
  {
    value: "ADMIN",
    label: "ADMIN",
  },
];

const statedropdownValue = [
  {
    value: "Active",
    label: "Active",
  },
  {
    value: "Inactive",
    label: "Inactive"
  },
];



const AddUser = ({ fetchData, handleClose, setIsSuccess,
  setIsError,
  setResponseErrorMessage,
  setProgress
}) => {
  const theme = useTheme();

  const [roleName, setRoleName] = useState("");
  const [orgName, setorgName] = useState("");
  const [createdDate, setCreatedDate] = useState("");
  const [rolestate, setrolestate] = useState("");
  const [roleId, setRoleId] = useState("");
  const [userState, setuserState] = useState('');
  const [isError, setIsMyError] = useState(false);

  const handleDateChange = (event) => {
    const timestamp = event.target.valueAsNumber;
    const newDate = new Date(timestamp);
    const year = newDate.getFullYear();
    const month = String(newDate.getMonth() + 1).padStart(2, "0");
    const day = String(newDate.getDate()).padStart(2, "0");
    const formattedDate = `${year}-${month}-${day}`;
    setCreatedDate(formattedDate);
  };



  const handleAdd = async (event) => {
    event.preventDefault()
    setProgress(20)
    console.log('Helo');
    const data = {
      roleName: roleName,
      orgName: orgName,
      rolestate: rolestate,
      roleId: roleId,
      createdDate: createdDate,
      // date: date
    };

    console.log("DATA FOR BACK", data)
    console.log("date")

    try {
      const response = await axios.post('http://192.168.1.15:8098/api/v1/role/addrole', data);
      console.log("data addedd successfully");
      console.log(response.data);
      console.log("date", createdDate)
      fetchData();
      setIsSuccess(true);
      handleClose();
      setProgress(60)
    } catch (e) {
      handleClose();
      console.log(e);
      setIsError(true)
      setResponseErrorMessage(e.response.data.message);
      setProgress(60)

    }
    setProgress(100)
  };
  // const createdTimestamp = 1649860147000; // assuming this is the integer representing the date

  // const createdDate = new Date(createdTimestamp);

  // const formattedDate = createdDate.toISOString().split('T')[0];




  return (
    <form onSubmit={handleAdd}>
      <Box
        sx={{
          my: 0.5,
          mx: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "left",
        }}
      >
        <Typography
          sx={{
            fontStyle: "Montserrat",
            fontWeight: "600",
            fontSize: "20px",
            color: "#4D47C3",
            lineHeight: "24px",
            fontFamily: "Montserrat",
            marginTop: '1px'
            // padding:  '6px'
          }}
        >
          Add Role
        </Typography>

        <Divider sx={{ marginTop: "1.5rem", borderBottomWidth: 2 }} />

        <Grid container spacing={2}>
          <Grid item xs={12} sm={4}>
            <Typography sx={{ color: "#8D8D8E" }} mt={3}>
              Role Name*
            </Typography>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Typography sx={{ color: "#8D8D8E" }} mt={3}>
              Organization Name*
            </Typography>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Typography sx={{ color: "#8D8D8E" }} mt={3}>
              Created Date*
            </Typography>
          </Grid>

          <Grid item xs={12} sm={4}>
            <Box
              component="form"
              sx={{
                "& .MuiTextField-root": { width: 1 },
              }}
            >
              <CustomTextField
                required
                id="outlined-select-currency"
                select
                value={roleName}
                onChange={(event) => setRoleName(event.target.value)}
                sx={{ backgroundColor: "#F0EFFF" }}
              >
                {roledropdownValue.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </CustomTextField>
            </Box>
          </Grid>
          <Grid item xs={12} sm={4}>
            <CustomTextField
              required
              fullWidth
              id="orgName"
              name="orgnName"
              autoComplete="family-name"
              value={orgName}
              onChange={(event) => setorgName(event.target.value)}
              sx={{ backgroundColor: "#F0EFFF" }}
            />
          </Grid>

          <Grid item xs={12} sm={4}>
            <CustomTextField
              required
              fullWidth
              type="date"
              id="formattedDate"
              name="formattedDate"
              autoComplete="family-name"
              value={createdDate}
              onChange={handleDateChange}
            />


          </Grid>


        </Grid>

        <Grid container spacing={2} mt={1}>
          <Grid item xs={12} sm={4}>
            <Typography sx={{ color: "#8D8D8E" }}>Role Status*</Typography>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Typography sx={{ color: "#8D8D8E" }}>Role ID*</Typography>
          </Grid>

          <Grid item xs={12} sm={4}>

          </Grid>

          <Grid item xs={12} sm={4}>
            <Box
              component="form"
              sx={{
                "& .MuiTextField-root": { width: 1 },
              }}
              noValidate
              autoComplete="off"
            >
              <CustomTextField
                required
                id="outlined-select-currency"
                select
                type='Boolean'
                value={rolestate}
                onChange={(event) => setrolestate(event.target.value)}
                sx={{ backgroundColor: "#F0EFFF" }}
              >
                {statedropdownValue.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </CustomTextField>
            </Box>

          </Grid>
          <Grid item xs={12} sm={4}>
            <CustomTextField
              required
              fullWidth

              id="roleId"
              name="roleId"
              value={roleId}
              sx={{ backgroundColor: "#F0EFFF" }}
              error={isError}
              onChange={(event) => setRoleId(event.target.value)}
            />
          </Grid>
        </Grid>

        <Grid item xs={15} sm={12} mt={3}>
          <Stack spacing={2} direction="row">
            <PrimaryButton
              sx={{ height: '40px', width: '110px', borderRadius: '6px', padding: '14px, 60px, 14px, 61px', fontFamily: "Montserrat" }}
              type='Submit'
              variant="contained">
              Add
            </PrimaryButton>
          </Stack>
        </Grid>
      </Box>
    </form>
  );
};

export default AddUser;
