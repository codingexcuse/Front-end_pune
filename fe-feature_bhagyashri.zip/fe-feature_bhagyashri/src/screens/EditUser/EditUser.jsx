import { useState } from "react";
import TextField from "@mui/material/TextField";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import MenuItem from "@mui/material/MenuItem";
import Stack from "@mui/material/Stack";
import styledComponent from "styled-components";
import "./styles.css";
import { useTheme } from "@mui/material";
import axios from "axios";
import PrimaryButton from "../../components/PrimaryButton/PrimaryButton";
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import Divider from "@mui/material/Divider";

const CustomTextField = styledComponent(TextField)`
  & label.Mui-focused {
    color: #4D47C3;
  }
  & .MuiOutlinedInput-root {
    &.Mui-focused fieldset {
      border-color: #4D47C3;
    }
  }
`;

const roledropdownValue = [
  {
    value: "SUPER_ADMIN",
    label: "SUPER_ADMIN",
  },
  {
    value: "ADMIN",
    label: "ADMIN",
  },
];

const statedropdownValue = [
  {
    value: "Active",
    label: "Active",
  },
  {
    value: "Inactive",
    label: "Inactive",
  },
];


const EditUser = ({ fetchData, handleClose, data, setIsSuccess,
  setIsError,
  setResponseErrorMessage, 
  setProgress}) => {
  const theme = useTheme();
  console.log("EDIT DATA", data)
  const [roleName, setRoleName] = useState(data.roleName);
  const [orgName, setOrgName] = useState(data.orgName);
  const [createddate, setcreateddate] = useState(data.createddate);
  const [rolestate, setrolestate] = useState(data.rolestate);
  const [roleId, setRoleId] = useState(data.roleId);

  const handleEdit = async (event) => {
    event.preventDefault()
    setProgress(20)
    const updatedata = {
      roleName: roleName,
      orgName: orgName,
      createddate: createddate,
      rolestate: rolestate,
      roleId: roleId
    };
    //Edit Role API here
    try {
      const response = await axios.put(`http://192.168.1.15:8098/api/v1/role/editrole/${roleId}`, updatedata);
      console.log("Data Edited successfully");
      // console.log(response.data);
      fetchData();
      setIsSuccess(true);
      handleClose();
      setProgress(60)
    } catch (e) { 
      handleClose();
      console.log(e);
      setIsError(true)
      setResponseErrorMessage(e.response.data.message);
      setProgress(60)
    }
    setProgress(100);
  };

  return (
      <Box
        sx={{
          my: 0.5,
          mx: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "left",
        }}
      >
        <Typography
          sx={{
            fontStyle: "Montserrat",
            fontWeight: "600",
            fontSize: "20px",
            color: "#4D47C3",
            lineHeight: "24px",
            fontFamily: "Montserrat"
          }}
        >
          Edit Role
        </Typography>

        <Divider sx={{ marginTop: "1.5rem", borderBottomWidth: 2 }} />

        <Grid container spacing={2}>
          <Grid item xs={12} sm={4}>
            <Typography sx={{ color: "#8D8D8E" }} mt={3}>
              Role Name
            </Typography>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Typography sx={{ color: "#8D8D8E" }} mt={3}>
            Organization Name
            </Typography>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Typography sx={{ color: "#8D8D8E" }} mt={3}>
             Created Date
            </Typography>
          </Grid>
         
           <Grid item xs={12} sm={4}>
            <Box
              component="form"
              sx={{
                "& .MuiTextField-root": { width: 1 },
              }}
              noValidate
              autoComplete="off"
            >
              <CustomTextField
                required
                id="outlined-select-currency"
                select
                // label="Organization Name"
                value={roleName}
                onChange={(event) => setRoleName(event.target.value)}
                sx = {{backgroundColor: "#F0EFFF"}}
              >
                {roledropdownValue.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </CustomTextField>
            </Box>

          </Grid>
          <Grid item xs={12} sm={4}>
            <CustomTextField
              required
              fullWidth
              id="orgName"
             
              name="orgName"
              autoComplete="family-name"
              value={orgName}
              onChange={(event) => setOrgName(event.target.value)}
              sx = {{backgroundColor: "#F0EFFF"}}
            />
          </Grid>
          <Grid item xs={12} sm={4}>
            <CustomTextField
              required
              fullWidth
              type='date'
              id="createddate"
              name="createddate"
              autoComplete="family-name"
              value={createddate}
              onChange={(event) => setcreateddate(event.target.value)}
              sx = {{backgroundColor: "#F0EFFF"}}
            />
          </Grid>
          {/* <Grid item xs={12} sm={4}>
          <DatePicker sx={{width:"285px"}} onChange={(event) => setDate(event.target.value)}/>
          </Grid> */}
        </Grid>

        <Grid container spacing={2} mt={1}>
          <Grid item xs={12} sm={4}>
            <Typography sx={{ color: "#8D8D8E" }}>Role Status</Typography>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Typography sx={{ color: "#8D8D8E" }}>Role ID</Typography>
          </Grid>

          <Grid item xs={12} sm={4}>
            
          </Grid>
         
           <Grid item xs={12} sm={4}>
            <Box
              component="form"
              sx={{
                "& .MuiTextField-root": { width: 1 },
              }}
              noValidate
              autoComplete="off"
            >
              <CustomTextField
                required
                id="outlined-select-currency"
                select
                // label="Organization Name"
                type='Boolean'
                value={rolestate}
                onChange={(event) => setrolestate(event.target.value)}
                sx = {{backgroundColor: "#F0EFFF"}}
              >
                {statedropdownValue.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </CustomTextField>
            </Box>

          </Grid>
          <Grid item xs={12} sm={4}>
            <CustomTextField
              required
              fullWidth
              id="roleId"
              name="roleId"
              value={roleId}
              onChange={(event) => setRoleId(event.target.value)}
              sx = {{backgroundColor: "#F0EFFF"}}
            />
          </Grid>
        </Grid>

        <Grid item xs={15} sm={12} mt={3}>
          <Stack spacing={2} direction="row">
            <PrimaryButton 
            sx={{height: '40px' , width: '110px' , borderRadius: '6px', padding: '14px, 60px, 14px, 61px', fontFamily: "Montserrat"}}
            variant="contained" 
            onClick={handleEdit}>
              Update
            </PrimaryButton>
          </Stack>
        </Grid>
      </Box>
  );
};

export default EditUser;
