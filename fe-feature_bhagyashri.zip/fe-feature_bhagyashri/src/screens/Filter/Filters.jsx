import { useState, useEffect } from "react";
import TextField from "@mui/material/TextField";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import MenuItem from "@mui/material/MenuItem";
import Stack from "@mui/material/Stack";
import styledComponent from "styled-components";
import "./styles.css";
import { useTheme } from "@mui/material";
import axios from "axios";
import PrimaryButton from "../../components/PrimaryButton/PrimaryButton";
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import Divider from "@mui/material/Divider";


const CustomTextField = styledComponent(TextField)`
  & label.Mui-focused {
    color: #4D47C3;
  }
  & .MuiOutlinedInput-root {
    &.Mui-focused fieldset {
      border-color: #4D47C3;
    }
  }
`;

const roledropdownValue = [
  {
    value: "SUPER_ADMIN",
    label: "SUPER_ADMIN",
  },
  {
    value: "ADMIN",
    label: "ADMIN",
  },
];

const statedropdownValue = [
  {
    value: "true",
    label: "Active",
  },
  {
    value: "false",
    label: "Inactive",
  },
];



const Filters = ({ handleClose, setData, data }) => {
  const theme = useTheme();

  const [roleName, setRoleName] = useState("");
  const [organizationName, setOrganizationName] = useState("");
  const [date, setDate] = useState("");
  const [roleState, setRoleState] = useState("");
  const [roleId, setRoleId] = useState("");
  const [filteredProducts, setFilteredProducts] = useState([]);

  const handleFilter = async () => {
    handleClose();
    const data = {
      roleName: roleName,
      organizationName: organizationName,
      date: date,
      roleState: roleState,
      roleId: roleId
    };
    try {
      const response = await fetch(`http://192.168.1.15:8098/api/v1/role/filtered?roleId=${roleId}`);
      const data = await response.json();
      setData(data);
      // setData(filteredProducts)
      console.log("data Filtered successfully", data);
      // fetchData();
    } catch (e) {
      console.log(e);
    }
  };
  // useEffect(() => {
  //   fetchData();
  // }, [roleName]);

  useEffect(() => {
    console.log("Filtered Products: ", filteredProducts);
  }, [filteredProducts])

  return (
    <Box
      sx={{
        my: 0.5,
        mx: 8,
        display: "flex",
        flexDirection: "column",
        alignItems: "left",
      }}
    >
      <Typography
        sx={{
          fontStyle: "normal",
          fontWeight: "600",
          fontSize: "20px",
          color: "#4D47C3",
          lineHeight: "24px",
          fontFamily: "Montserrat"
        }}
      >
        Filters
      </Typography>

      <Divider sx={{ marginTop: "2rem", borderBottomWidth: 2 }} />

      <Grid container spacing={1}>
        <Grid item xs={12} sm={4}>
          <Typography sx={{ color: "#8D8D8E" }} mt={3}>
            Role Name
          </Typography>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Typography sx={{ color: "#8D8D8E" }} mt={3}>
            Organization Name
          </Typography>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Typography sx={{ color: "#8D8D8E" }} mt={3}>
            Created Date
          </Typography>
        </Grid>

        <Grid item xs={12} sm={4}>
          <Box
            component="form"
            sx={{
              "& .MuiTextField-root": { width: 1 },
            }}
            noValidate
            autoComplete="off"
          >
            <CustomTextField
              required
              id="outlined-select-currency"
              select
              value={roleName}
              onChange={(event) => setRoleName(event.target.value)}
              sx={{ backgroundColor: "#F0EFFF" }}
            >
              {roledropdownValue.map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </CustomTextField>
          </Box>

        </Grid>
        <Grid item xs={12} sm={4}>
          <CustomTextField
            required
            fullWidth
            id="organizationName"
            name="organizationName"
            autoComplete="family-name"
            value={organizationName}
            onChange={(event) => setOrganizationName(event.target.value)}
            sx={{ backgroundColor: "#F0EFFF" }}
          />
        </Grid>
        <Grid item xs={12} sm={4}>
          <CustomTextField
            required
            fullWidth
            type='date'
            id="date"
            name="date"
            autoComplete="family-name"
            value={date}
            onChange={(event) => setDate(event.target.value)}
            sx={{ backgroundColor: "#F0EFFF" }}
          />
        </Grid>

      </Grid>

      <Grid container spacing={1} mt={1}>
        <Grid item xs={12} sm={4}>
          <Typography sx={{ color: "#8D8D8E" }}>Role Status</Typography>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Typography sx={{ color: "#8D8D8E" }}>Role ID</Typography>
        </Grid>

        <Grid item xs={12} sm={4}>

        </Grid>

        <Grid item xs={12} sm={4}>
          <Box
            component="form"
            sx={{
              "& .MuiTextField-root": { width: 1 },
            }}
            noValidate
            autoComplete="off"
          >
            <CustomTextField
              required
              id="outlined-select-currency"
              select
              value={roleState}
              onChange={(event) => setRoleState(event.target.value)}
              sx={{ backgroundColor: "#F0EFFF" }}
            >
              {statedropdownValue.map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </CustomTextField>
          </Box>

        </Grid>
        <Grid item xs={12} sm={4}>
          <CustomTextField
            required
            fullWidth
            id="roleId"
            // label="companyId"
            name="roleId"
            value={roleId}
            onChange={(event) => setRoleId(event.target.value)}
            sx={{ backgroundColor: "#F0EFFF" }}
          />
        </Grid>
      </Grid>

      <Grid item xs={12} sm={12} mt={3}>
        <Stack spacing={2} direction="row">
          <PrimaryButton variant="contained"
            sx={{
              fontFamily: "Montserrat",
              borderRadius: '6px', padding: '14px, 60px, 14px, 61px'
            }}
            onClick={handleFilter}>
            Continue
          </PrimaryButton>
        </Stack>
      </Grid>


      <Box sx={{ flexGrow: 1, position: "relative", left: "23px" }} width="95%" height="400px">
        {filteredProducts.map((role, index) => {
          return (
            <Grid
              key={index}
              container spacing={2}
              sx={{
                borderRadius: "8px",
                backgroundColor: theme.palette.secondary.main,
                marginTop: "1rem",
              }}
            >
              <Grid item xs={2}>
                <Typography sx={{ fontSize: 14, marginBottom: "1rem", width: '76px', height: '21px' }}>
                  {role.roleName}
                </Typography>
              </Grid>
              <Grid item xs={2.8}  >
                <Typography sx={{ fontSize: 14, width: '135px', height: '21px' }}>{role.orgName}</Typography>
              </Grid>
              <Grid item xs={1.9}>
                <Typography sx={{ fontSize: 14, width: '95px', height: '21px' }}>
                  {role.createddate}
                </Typography>
              </Grid>
              <Grid item xs={1.7}>
                <Typography sx={{ fontSize: 14, width: '70px', height: '21px' }}>
                  {role.rolestate ? "ACTIVE" : "INACTIVE"}
                </Typography>
              </Grid>
              <Grid item xs={1.5}>
                <Typography sx={{ fontSize: 14, width: '47px', height: '21px' }}>
                  {role.roleId}
                </Typography>
              </Grid>

            </Grid>
          );
        })}
      </Box>
    </Box>
  );
};

export default Filters;
