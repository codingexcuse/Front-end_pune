import * as React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import { useTheme } from "@mui/material";
import PrimaryButton from "../PrimaryButton/PrimaryButton";
export default function AlertDialog({ deleteById, id }) {
  const [open, setOpen] = React.useState(false);
  const theme = useTheme();

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleCloseDelete = () => {
    setOpen(false);
    deleteById(id);
  };

  const handleCloseCancel = () => {
    setOpen(false);
  };

  return (
    <>
      <DeleteOutlineOutlinedIcon
        onClick={handleClickOpen}
        fontSize="small"
        sx={{
          marginLeft: "2rem",
          cursor: "pointer",
          color: theme.palette.primary.main,
        }}
      />
      <Dialog
        open={open}
        onClose={handleCloseCancel}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{"Delete?"}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Are you sure you want to delete?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          
          <PrimaryButton 
             sx={{height: '40px' , width: '100px', borderRadius: '6px', padding: '70px, 70px, 70px, 70px'}}
             
              variant="contained" 
              onClick={handleCloseCancel} >
              Cancle
            </PrimaryButton>
       
          <PrimaryButton 
             sx={{height: '40px' , width: '100px', borderRadius: '6px'}}
             
              variant="contained" 
              onClick={handleCloseDelete} >
              Delete
            </PrimaryButton>
        </DialogActions>
      </Dialog>
    </>
  );
}
