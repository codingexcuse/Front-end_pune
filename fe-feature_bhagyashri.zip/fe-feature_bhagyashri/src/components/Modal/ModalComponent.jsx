import React from 'react'
import { Backdrop, Modal, Fade, IconButton } from "@mui/material";
import CloseSharpIcon from "@mui/icons-material/CloseSharp";
import { useTheme } from "@mui/material";
import ClearButton from "../../components/ClearButton/ClearButton";



const ModalComponent = ({ 
  open, 
  setData,
  handleClose, 
  fetchData, 
  Component, 
  showClear, 
  data, 
  setIsError,
  setIsSuccess,
  setResponseErrorMessage,
  setProgress
}) => {
  const theme = useTheme()
  return (
    <Modal

      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={open}
      // onClose={handleClose}
      closeAfterTransition
      BackdropComponent={Backdrop}
      BackdropProps={{
        timeout: 500,
      }}
    >
      <Fade in={open}>
        <div className="popform">
          {showClear === true && <ClearButton
            sx={{ position: "relative", left: "47rem", top: "3.9rem", fontFamily: "Montserrat" }}
            size="small"
            variant="outlined"
          >
            Clear Filters
          </ClearButton>}

          <IconButton
            size="small"
            onClick={handleClose}
            sx={{
              position: "relative",
              top: "1.8rem",
              marginLeft: "895px",
              marginTop: "1px",
              backgroundColor: theme.palette.secondary.main,
              color: theme.palette.primary.main,
              borderRadius: "0.5rem",
            }}
          >
            <CloseSharpIcon />
          </IconButton>
          <Component
          setData={setData}
            fetchData={fetchData}
            data={data}
            handleClose={handleClose}
            setIsError={setIsError}
            setIsSuccess={setIsSuccess}
            setResponseErrorMessage={setResponseErrorMessage}
            setProgress={setProgress} />
        </div>
      </Fade>
    </Modal>)
}

export default ModalComponent